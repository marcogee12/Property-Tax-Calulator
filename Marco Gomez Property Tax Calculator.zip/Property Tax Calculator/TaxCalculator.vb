﻿Public Class TaxCalculator
    Private Sub exitBtn_Click(sender As Object, e As EventArgs) Handles exitBtn.Click
        Me.Close()
    End Sub

    Public Sub calcTax_Click(sender As Object, e As EventArgs) Handles calcTax.Click
        Dim PropTax As Double = PropVal.Text / 100 * 1.35
        Dim Tax As String = "Total Property Tax is " & FormatCurrency(PropTax.ToString)
        MessageBox.Show(Tax)
    End Sub

End Class
